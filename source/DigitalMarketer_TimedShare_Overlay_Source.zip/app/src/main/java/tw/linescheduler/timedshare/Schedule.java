package tw.linescheduler.timedshare;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

final class Schedule {
    static final String PREFS = "share_schedule";
    static final String WHEN = "when";
    static final String STATE = "state";
    static final String ARMED_PACKAGE = "armedPackage";
    static final String ARMED_COUNT = "armedCount";

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE); }

    private static PendingIntent pending(Context c) {
        return PendingIntent.getBroadcast(c, 17, new Intent(c, TriggerReceiver.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    static boolean schedule(Context c, long when) {
        if (when <= System.currentTimeMillis() + 3000) return false;
        AlarmManager a = c.getSystemService(AlarmManager.class);
        if (a == null || !a.canScheduleExactAlarms()) return false;
        a.cancel(pending(c));
        // Clear old pinned recipient context. New schedule must re-arm on the user's visible LINE screen.
        prefs(c).edit().putLong(WHEN, when).putString(STATE, "已預約｜請返回 LINE，保持已選收件人的分享畫面")
                .remove(ARMED_PACKAGE).remove(ARMED_COUNT).apply();
        try { a.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pending(c)); }
        catch (SecurityException ex) { cancel(c, "缺少精準鬧鐘權限"); return false; }
        return true;
    }

    static void cancel(Context c, String state) {
        AlarmManager a = c.getSystemService(AlarmManager.class);
        if (a != null) a.cancel(pending(c));
        prefs(c).edit().remove(WHEN).remove(ARMED_PACKAGE).remove(ARMED_COUNT).putString(STATE, state).apply();
    }

    static void mark(Context c, String state) { prefs(c).edit().putString(STATE, state).apply(); }
}
