package tw.linescheduler.timedshare;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.KeyguardManager;
import android.content.SharedPreferences;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.view.Gravity;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ShareAccessibilityService extends AccessibilityService {
    static volatile ShareAccessibilityService current;
    private static final Pattern SELECTED=Pattern.compile("已選\\s*[（(]?\\s*(\\d+)\\s*[)）]?");
    private final Handler handler=new Handler(Looper.getMainLooper());
    private WindowManager wm;
    private LinearLayout panel;
    private TextView countdown;

    private static final class Screen {
        String pkg;
        int selected=-1;
        boolean title, chat, groups, friends;
        AccessibilityNodeInfo share;
        boolean valid;
    }

    @Override protected void onServiceConnected(){
        super.onServiceConnected();
        current=this;
        makePanel();
        handler.post(tick);
    }
    private int dp(int value){return (int)(getResources().getDisplayMetrics().density*value+0.5f);}
    private void info(String message){Toast.makeText(this,message,Toast.LENGTH_LONG).show();}
    private Button button(String title){
        Button b=new Button(this);b.setText(title);b.setAllCaps(false);b.setTextSize(13);b.setMinHeight(dp(42));return b;
    }
    private void makePanel() {
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        panel=new LinearLayout(this);panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(3),dp(3),dp(3),dp(3));panel.setBackgroundColor(0xDFF5F8FF);
        Button reserve=button("預約分享");
        Button cancel=button("取消預約");
        countdown=new TextView(this);countdown.setTextSize(12);countdown.setGravity(Gravity.CENTER);
        countdown.setTextColor(0xFF222222);countdown.setText("未預約");
        panel.addView(reserve);panel.addView(cancel);panel.addView(countdown);
        reserve.setOnClickListener(v->askWhen());
        cancel.setOnClickListener(v->{Schedule.cancel(this,"使用者取消，沒有傳送");info("預約已取消");});
        WindowManager.LayoutParams p=new WindowManager.LayoutParams(
                dp(118),WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        p.gravity=Gravity.END|Gravity.CENTER_VERTICAL;
        p.x=0;p.y=0;
        try{wm.addView(panel,p);}catch(Exception e){panel=null;info("浮動按鈕顯示失敗，請重新開啟無障礙");}
    }
    private final Runnable tick=new Runnable(){
        @Override public void run(){
            if(countdown!=null) {
                long when=Schedule.prefs(ShareAccessibilityService.this).getLong(Schedule.WHEN,0L);
                if(when>0){
                    long seconds=Math.max(0,(when-System.currentTimeMillis()+999)/1000);
                    countdown.setText("倒數 "+(seconds/3600)+":"+String.format(Locale.ROOT,"%02d:%02d",(seconds%3600)/60,seconds%60));
                }else{
                    String s=Schedule.prefs(ShareAccessibilityService.this).getString(Schedule.STATE,"未預約");
                    countdown.setText(s.contains("已按")?"已按分享":s.contains("未發送")?"未發送":"未預約");
                }
            }
            handler.postDelayed(this,1000);
        }
    };
    private void askWhen(){
        Screen before=inspect();
        if(before==null||!before.valid){info("請先在 LINE 選好收件人，並停留在分享畫面");return;}
        AlarmManager am=getSystemService(AlarmManager.class);
        if(am==null||!am.canScheduleExactAlarms()){
            info("請先開啟此 APP 的精準鬧鐘權限");return;
        }
        EditText input=new EditText(this);
        SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.TAIWAN);
        input.setSingleLine(true);
        input.setText(f.format(new Date(System.currentTimeMillis()+5*60*1000)));
        AlertDialog d=new AlertDialog.Builder(this)
                .setTitle("預約分享時間")
                .setMessage("已選 "+before.selected+" 位收件人。手機須亮屏、解鎖，並保持在 LINE 分享畫面。")
                .setView(input)
                .setNegativeButton("取消",(dlg,which)->{})
                .setPositiveButton("確認預約",(dlg,which)->{
                    try{
                        SimpleDateFormat fmt=new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.TAIWAN);
                        fmt.setLenient(false);
                        Date date=fmt.parse(input.getText().toString().trim());
                        if(date==null)throw new ParseException("missing",0);
                        long when=date.getTime();
                        if(when<System.currentTimeMillis()+10000 || when>System.currentTimeMillis()+30L*86400000L){info("請設定未來30天內的時間");return;}
                        handler.postDelayed(()->{
                            Screen now=inspect();
                            if(now==null||!now.valid||!before.pkg.equals(now.pkg)||before.selected!=now.selected){
                                info("LINE 畫面已改變，沒有建立預約");return;
                            }
                            if(!Schedule.schedule(this,when)){info("預約失敗，請檢查精準鬧鐘權限");return;}
                            Schedule.prefs(this).edit()
                                    .putString(Schedule.ARMED_PACKAGE,before.pkg)
                                    .putInt(Schedule.ARMED_COUNT,before.selected)
                                    .putString(Schedule.STATE,"已就緒｜等待分享 "+before.selected+" 位收件人")
                                    .apply();
                            info("預約成功，請保持 LINE 畫面開啟");
                        },500);
                    }catch(Exception ex){info("時間格式錯誤，請輸入 YYYY-MM-DD HH:mm");}
                }).create();
        if(d.getWindow()!=null)d.getWindow().setType(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY);
        try{d.show();}catch(Exception e){info("無法顯示預約視窗："+e.getMessage());}
    }
    private void collect(AccessibilityNodeInfo n,List<AccessibilityNodeInfo> out,int depth){
        if(n==null||depth>35||out.size()>4000)return;
        out.add(n);
        for(int i=0;i<n.getChildCount();i++)collect(n.getChild(i),out,depth+1);
    }
    private String text(AccessibilityNodeInfo n){
        CharSequence a=n.getText(),b=n.getContentDescription();
        return a!=null&&a.length()>0?a.toString().trim():b!=null?b.toString().trim():"";
    }
    private AccessibilityNodeInfo findLineRoot(){
        AccessibilityNodeInfo root=getRootInActiveWindow();
        if(root!=null && root.getPackageName()!=null && root.getPackageName().toString().toLowerCase(Locale.ROOT).contains("line"))return root;
        try{
            for(AccessibilityWindowInfo w:getWindows()){
                AccessibilityNodeInfo candidate=w.getRoot();
                if(candidate!=null && candidate.getPackageName()!=null && candidate.getPackageName().toString().toLowerCase(Locale.ROOT).contains("line"))return candidate;
            }
        }catch(Exception ignored){}
        return root;
    }
    private Screen inspect(){
        AccessibilityNodeInfo root=findLineRoot();
        if(root==null||root.getPackageName()==null)return null;
        Screen s=new Screen();s.pkg=root.getPackageName().toString();
        if(!s.pkg.toLowerCase(Locale.ROOT).contains("line"))return null;
        List<AccessibilityNodeInfo> all=new ArrayList<>();collect(root,all,0);
        int width=getResources().getDisplayMetrics().widthPixels;
        int top=dp(190);
        for(AccessibilityNodeInfo node:all){
            String value=text(node);
            if(value.isEmpty())continue;
            if(value.contains("選擇傳送對象"))s.title=true;
            if(value.equals("聊天"))s.chat=true;
            if(value.equals("好友"))s.friends=true;
            if(value.equals("群組"))s.groups=true;
            Matcher m=SELECTED.matcher(value);
            if(m.find())try{int c=Integer.parseInt(m.group(1));if(c>0&&c<10000)s.selected=c;}catch(NumberFormatException ignored){}
            if(value.equals("分享")&&node.isEnabled()){
                Rect r=new Rect();node.getBoundsInScreen(r);
                if(r.width()>0&&r.height()>0&&r.centerX()>width*0.63f&&r.centerY()<top)
                    if(s.share==null||r.centerY()<topOf(s.share))s.share=node;
            }
        }
        s.valid=s.selected>0&&s.share!=null&&(s.title||((s.chat?1:0)+(s.friends?1:0)+(s.groups?1:0)>=2));
        return s;
    }
    private int topOf(AccessibilityNodeInfo n){Rect r=new Rect();n.getBoundsInScreen(r);return r.centerY();}
    private boolean click(AccessibilityNodeInfo target){
        AccessibilityNodeInfo n=target;
        for(int i=0;i<4&&n!=null;i++,n=n.getParent()){
            Rect r=new Rect();n.getBoundsInScreen(r);
            if(n.isEnabled()&&n.isClickable()&&r.centerY()<dp(190)&&n.performAction(AccessibilityNodeInfo.ACTION_CLICK))return true;
        }
        return false;
    }
    void runScheduledAction(long expected){
        SharedPreferences p=Schedule.prefs(this);
        if(p.getLong(Schedule.WHEN,0L)!=expected)return;
        String pkg=p.getString(Schedule.ARMED_PACKAGE,"");int count=p.getInt(Schedule.ARMED_COUNT,-1);
        // Consume before attempting send: no duplicate transmission after alarm redelivery.
        p.edit().remove(Schedule.WHEN).remove(Schedule.ARMED_COUNT).remove(Schedule.ARMED_PACKAGE)
                .putString(Schedule.STATE,"送出前核對中").commit();
        PowerManager power=getSystemService(PowerManager.class);
        KeyguardManager lock=getSystemService(KeyguardManager.class);
        if(power==null||!power.isInteractive()||(lock!=null&&lock.isDeviceLocked())){
            Schedule.mark(this,"未發送：手機已鎖定或畫面關閉");return;
        }
        Screen s=inspect();
        if(s==null||!s.valid||pkg.isEmpty()||count<1||!s.pkg.equals(pkg)||s.selected!=count){
            Schedule.mark(this,"未發送：帳號或收件人畫面已改變");return;
        }
        if(click(s.share)){
            Schedule.mark(this,"已按分享｜請至 LINE 確認送達");return;
        }
        Rect r=new Rect();s.share.getBoundsInScreen(r);
        int width=getResources().getDisplayMetrics().widthPixels;
        if(r.centerX()<=width*0.63f||r.centerY()>=dp(190)){
            Schedule.mark(this,"未發送：不是右上角分享按鈕");return;
        }
        Path path=new Path();path.moveTo(r.centerX(),r.centerY());
        GestureDescription.StrokeDescription stroke=new GestureDescription.StrokeDescription(path,0,90);
        GestureDescription gesture=new GestureDescription.Builder().addStroke(stroke).build();
        boolean dispatched=dispatchGesture(gesture,new GestureResultCallback(){
            @Override public void onCompleted(GestureDescription gd){Schedule.mark(ShareAccessibilityService.this,"已點右上角分享｜請至 LINE 確認送達");}
            @Override public void onCancelled(GestureDescription gd){Schedule.mark(ShareAccessibilityService.this,"未發送：點擊被取消");}
        },handler);
        if(!dispatched)Schedule.mark(this,"未發送：無法點擊分享");
    }
    @Override public void onAccessibilityEvent(AccessibilityEvent e){}
    @Override public void onInterrupt(){}
    @Override public void onDestroy(){
        handler.removeCallbacks(tick);
        if(panel!=null&&wm!=null)try{wm.removeView(panel);}catch(Exception ignored){}
        if(current==this)current=null;
        super.onDestroy();
    }
}
