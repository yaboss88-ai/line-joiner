package tw.linescheduler.timedshare;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class TriggerReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        long scheduled = Schedule.prefs(context).getLong(Schedule.WHEN, 0L);
        long now = System.currentTimeMillis();
        if (scheduled == 0L || now < scheduled - 10000) return;
        // Do not leave the timer armed if its target was lost or app was stopped.
        ShareAccessibilityService service = ShareAccessibilityService.current;
        if (service == null) {
            Schedule.cancel(context, "已停止：無障礙服務沒有運作，未點擊分享");
            return;
        }
        service.runScheduledAction(scheduled);
    }
}
