package tw.linescheduler.timedshare;

import android.app.Activity;
import android.app.AlarmManager;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private TextView status;
    private Button button(String label, View.OnClickListener l) {
        Button b=new Button(this); b.setText(label); b.setAllCaps(false);b.setOnClickListener(l);return b;
    }
    private TextView text(String s,int sp) {
        TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setPadding(6,16,6,16);return t;
    }
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.VERTICAL);
        v.setPadding(28,42,28,28);v.setGravity(Gravity.TOP);
        v.addView(text("數位行銷王｜預約分享",24));
        v.addView(text("保留原本的『數位行銷王』選群操作。\n選好收件人後，直接點 LINE 畫面右側的「預約分享」浮動按鈕。",17));
        v.addView(button("① 開啟無障礙服務",a->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));
        v.addView(button("② 開啟精準鬧鐘權限",a->requestExact()));
        v.addView(button("取消預約",a->{Schedule.cancel(this,"使用者取消，沒有傳送");refresh();}));
        status=text("",16);v.addView(status);
        v.addView(text("使用前請確認收件人同意接收。到時間手機須亮屏、解鎖，並保持在原本 LINE 的「選擇傳送對象」畫面；無法核對時停止，不會亂按。",14));
        setContentView(v);
        refresh();
    }
    private void requestExact() {
        try {startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).setData(Uri.parse("package:"+getPackageName())));}
        catch(ActivityNotFoundException ex){startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).setData(Uri.parse("package:"+getPackageName())));}
    }
    private void refresh(){
        if(status==null)return;
        AlarmManager a=getSystemService(AlarmManager.class);
        boolean alarm=a!=null && a.canScheduleExactAlarms();
        String accessibility=ShareAccessibilityService.current!=null?"已啟用":"未啟用";
        String task=Schedule.prefs(this).getString(Schedule.STATE,"尚未預約");
        status.setText("無障礙："+accessibility+"\n精準鬧鐘："+(alarm?"已允許":"未允許")+"\n狀態："+task);
    }
    @Override protected void onResume(){super.onResume();if(status!=null)refresh();}
}
