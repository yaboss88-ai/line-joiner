package tw.linescheduler.timedshare;

import android.app.Activity;
import android.app.AlarmManager;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.EditText;
import android.text.InputType;

public class MainActivity extends Activity {
    private TextView status;
    private EditText clickDelay, scrollDelay;
    private Button button(String label, View.OnClickListener l) {
        Button b=new Button(this); b.setText(label); b.setAllCaps(false);b.setOnClickListener(l);return b;
    }
    private TextView text(String s,int sp) {
        TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setPadding(6,16,6,16);return t;
    }
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.VERTICAL);
        v.setPadding(28,42,28,28);v.setGravity(Gravity.TOP);
        v.addView(text("數位行銷王｜選群＋定時分享",24));
        v.addView(text("同一個 APP 內完成 LINE 勾選與預約。打開 LINE 收件人畫面，左側可點「開始選取／暫停選取／預約分享」。",16));
        v.addView(button("① 開啟無障礙服務",a->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));
        v.addView(button("② 開啟精準鬧鐘權限",a->requestExact()));
        v.addView(text("點擊延遲（毫秒）",16));
        clickDelay=new EditText(this);clickDelay.setSingleLine(true);clickDelay.setInputType(InputType.TYPE_CLASS_NUMBER);
        clickDelay.setText(String.valueOf(Schedule.prefs(this).getInt("click_delay",180)));v.addView(clickDelay);
        v.addView(text("滑動延遲（毫秒）",16));
        scrollDelay=new EditText(this);scrollDelay.setSingleLine(true);scrollDelay.setInputType(InputType.TYPE_CLASS_NUMBER);
        scrollDelay.setText(String.valueOf(Schedule.prefs(this).getInt("scroll_delay",850)));v.addView(scrollDelay);
        v.addView(button("儲存選群速度",b->saveDelays()));
        v.addView(button("取消預約",a->{Schedule.cancel(this,"使用者取消，沒有傳送");refresh();}));
        status=text("",16);v.addView(status);
        v.addView(text("請只向同意接收者發送。先測試 1 個群組。到時間需保持手機亮屏、解鎖，且停留在 LINE 已選收件人畫面；畫面變動會停止，不會按 LINE VOOM。",14));
        setContentView(v);
        refresh();
    }
    private void saveDelays(){
        try{
            int click=Integer.parseInt(clickDelay.getText().toString().trim());
            int scroll=Integer.parseInt(scrollDelay.getText().toString().trim());
            if(click<120||click>3000||scroll<500||scroll>5000){
                android.widget.Toast.makeText(this,"點擊 120–3000；滑動 500–5000 毫秒",android.widget.Toast.LENGTH_LONG).show();return;
            }
            Schedule.prefs(this).edit().putInt("click_delay",click).putInt("scroll_delay",scroll).apply();
            android.widget.Toast.makeText(this,"速度已儲存",android.widget.Toast.LENGTH_SHORT).show();
        }catch(Exception e){android.widget.Toast.makeText(this,"請輸入有效數字",android.widget.Toast.LENGTH_LONG).show();}
    }
    private void requestExact() {
        try {startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).setData(Uri.parse("package:"+getPackageName())));}
        catch(ActivityNotFoundException ex){startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).setData(Uri.parse("package:"+getPackageName())));}
    }
    private void refresh(){
        if(status==null)return;
        AlarmManager a=getSystemService(AlarmManager.class);
        boolean alarm=a!=null && a.canScheduleExactAlarms();
        String accessibility=ShareAccessibilityService.current!=null?"已啟用":"未啟用";
        String task=Schedule.prefs(this).getString(Schedule.STATE,"尚未預約");
        status.setText("無障礙："+accessibility+"\n精準鬧鐘："+(alarm?"已允許":"未允許")+"\n預約狀態："+task);
    }
    @Override protected void onResume(){super.onResume();if(status!=null)refresh();}
}
