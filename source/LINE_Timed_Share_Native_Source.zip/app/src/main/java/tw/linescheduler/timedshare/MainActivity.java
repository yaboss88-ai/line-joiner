package tw.linescheduler.timedshare;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.app.Activity;
import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;

public class MainActivity extends Activity {
    private long selectedWhen = 0L;
    private TextView whenView, statusView;

    private TextView text(String s, float sp) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(sp);
        t.setPadding(4, 18, 4, 18); return t;
    }
    private Button button(String label, View.OnClickListener l) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setOnClickListener(l); return b;
    }
    private void selectWhen() {
        Calendar cal = Calendar.getInstance();
        if (selectedWhen > 0) cal.setTimeInMillis(selectedWhen);
        DatePickerDialog d = new DatePickerDialog(this, (view,y,m,day)-> {
            Calendar v = Calendar.getInstance(); v.set(y,m,day);
            new TimePickerDialog(this,(tp,h,min)-> {
                v.set(Calendar.HOUR_OF_DAY,h); v.set(Calendar.MINUTE,min); v.set(Calendar.SECOND,0); v.set(Calendar.MILLISECOND,0);
                selectedWhen = v.getTimeInMillis();
                whenView.setText("預約時間：" + DateFormat.getDateTimeInstance(DateFormat.SHORT,DateFormat.SHORT).format(new Date(selectedWhen)));
            }, cal.get(Calendar.HOUR_OF_DAY),cal.get(Calendar.MINUTE),true).show();
        },cal.get(Calendar.YEAR),cal.get(Calendar.MONTH),cal.get(Calendar.DAY_OF_MONTH));
        d.getDatePicker().setMinDate(System.currentTimeMillis()-60000); d.show();
    }
    private void requestAlarmPermission() {
        try { startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).setData(Uri.parse("package:"+getPackageName()))); }
        catch (ActivityNotFoundException e) { startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).setData(Uri.parse("package:"+getPackageName()))); }
    }
    private void arm() {
        AlarmManager am=getSystemService(AlarmManager.class);
        if (am==null||!am.canScheduleExactAlarms()) { requestAlarmPermission(); return; }
        if (ShareAccessibilityService.current==null) { statusView.setText("請先開啟無障礙服務，再按確認預約"); return; }
        if (Schedule.schedule(this, selectedWhen)) { refresh(); statusView.setText("已預約。請回 LINE 的選擇傳送對象畫面，維持亮屏、解鎖。"); }
        else statusView.setText("請選擇未來時間，再確認預約");
    }
    private void refresh(){
        long when=Schedule.prefs(this).getLong(Schedule.WHEN,0L);
        String state=Schedule.prefs(this).getString(Schedule.STATE,"尚未預約");
        statusView.setText(state+(when>0?"\n執行時間："+DateFormat.getDateTimeInstance().format(new Date(when)):""));
    }
    @Override protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        LinearLayout layout=new LinearLayout(this); layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(24,28,24,20); layout.setGravity(Gravity.TOP);
        TextView title=text("LINE 定時分享助手",25); layout.addView(title);
        layout.addView(text("先設定時間，再到「數位行銷王」選好收件人。到點只按 LINE 右上角「分享」。",16));
        whenView=text("尚未選擇時間",18); layout.addView(whenView);
        layout.addView(button("① 選擇日期與時間",v->selectWhen()));
        layout.addView(button("② 開啟無障礙服務",v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));
        layout.addView(button("③ 確認預約分享",v->arm()));
        layout.addView(button("取消預約",v->{Schedule.cancel(this,"已取消，沒有傳送");refresh();}));
        statusView=text("",17);layout.addView(statusView);
        layout.addView(text("⚠️ 使用前請先取得收件人同意。到點時手機必須亮屏、解鎖，並停在正確的 LINE「已選收件人」畫面。若無法核對畫面，程式不會按分享。",14));
        setContentView(layout);refresh();
    }
    @Override protected void onResume(){super.onResume();if(statusView!=null)refresh();}
}
