package tw.linescheduler.timedshare;

import android.accessibilityservice.AccessibilityService;
import android.app.KeyguardManager;
import android.content.SharedPreferences;
import android.graphics.Rect;
import android.os.PowerManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ShareAccessibilityService extends AccessibilityService {
    static volatile ShareAccessibilityService current;
    private long lastInspect;
    private static final Pattern SELECTED = Pattern.compile("已選\\s*[（(]?\\s*(\\d+)\\s*[)）]?");

    private static final class Screen {
        String pkg;
        int selected = -1;
        boolean hasTitle, chatTab, friendTab, groupTab;
        AccessibilityNodeInfo share;
        boolean validated;
    }

    @Override protected void onServiceConnected() {
        super.onServiceConnected();current=this;
    }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        long when=Schedule.prefs(this).getLong(Schedule.WHEN,0L);
        if (when==0) return;
        long now=System.currentTimeMillis();
        if (now-lastInspect<300) return;
        lastInspect=now;
        if (when<=now) return; // Alarm receiver exclusively handles the timed action.
        Screen s=inspect();
        if (s==null || !s.validated) return;
        SharedPreferences p=Schedule.prefs(this);
        String oldPkg=p.getString(Schedule.ARMED_PACKAGE,"");
        int oldCount=p.getInt(Schedule.ARMED_COUNT,-1);
        if (!oldPkg.isEmpty() && !oldPkg.equals(s.pkg)) {
            Schedule.mark(this,"已預約但偵測到不同 LINE 帳號，將停止發送，避免誤發");
            return;
        }
        if (oldPkg.equals(s.pkg) && oldCount==s.selected) return;
        p.edit().putString(Schedule.ARMED_PACKAGE,s.pkg).putInt(Schedule.ARMED_COUNT,s.selected)
                .putString(Schedule.STATE,"已就緒｜已核對 "+s.selected+" 位收件人，等待預約時間").apply();
    }

    private void collect(AccessibilityNodeInfo node, List<AccessibilityNodeInfo> nodes, int depth) {
        if (node==null || depth>30 || nodes.size()>4000) return;
        nodes.add(node);
        for (int i=0;i<node.getChildCount();i++) collect(node.getChild(i),nodes,depth+1);
    }
    private String text(AccessibilityNodeInfo n) {
        String a=n.getText()==null?"":n.getText().toString().trim();
        String b=n.getContentDescription()==null?"":n.getContentDescription().toString().trim();
        return a.isEmpty()?b:a;
    }
    private Screen inspect() {
        AccessibilityNodeInfo root=getRootInActiveWindow();
        if(root==null || root.getPackageName()==null) return null;
        Screen s=new Screen();
        s.pkg=root.getPackageName().toString();
        if (!s.pkg.toLowerCase(Locale.ROOT).contains("line")) return null;
        ArrayList<AccessibilityNodeInfo> nodes=new ArrayList<>();collect(root,nodes,0);
        float density=getResources().getDisplayMetrics().density;
        int width=getResources().getDisplayMetrics().widthPixels;
        for(AccessibilityNodeInfo n:nodes){
            String t=text(n);
            if(t.isEmpty())continue;
            if(t.contains("選擇傳送對象"))s.hasTitle=true;
            if(t.equals("聊天"))s.chatTab=true;
            if(t.equals("好友"))s.friendTab=true;
            if(t.equals("群組"))s.groupTab=true;
            Matcher m=SELECTED.matcher(t);
            if(m.find()){
                try{int count=Integer.parseInt(m.group(1)); if(count>0 && count<10000)s.selected=count;}
                catch(NumberFormatException ignored){}
            }
            // Never match '分享到 LINE VOOM' or any lower-page share element.
            if(t.equals("分享") && n.isEnabled()){
                Rect r=new Rect();n.getBoundsInScreen(r);
                if(r.width()>0 && r.height()>0 && r.centerX()>width*0.66f && r.centerY()<190*density){
                    if(s.share==null || r.centerY()<getTop(s.share))s.share=n;
                }
            }
        }
        s.validated = s.selected>0 && s.share!=null && (s.hasTitle || ((s.chatTab?1:0)+(s.friendTab?1:0)+(s.groupTab?1:0)>=2));
        return s;
    }
    private int getTop(AccessibilityNodeInfo n){Rect r=new Rect();n.getBoundsInScreen(r);return r.centerY();}
    private boolean click(AccessibilityNodeInfo n) {
        AccessibilityNodeInfo p=n;
        for(int k=0;k<4 && p!=null;k++,p=p.getParent()){
            if(p.isEnabled() && p.isClickable()) {
                Rect r=new Rect();p.getBoundsInScreen(r);
                if(r.centerY()<190*getResources().getDisplayMetrics().density) return p.performAction(AccessibilityNodeInfo.ACTION_CLICK);
            }
        }
        return false;
    }
    void runScheduledAction(long expected) {
        SharedPreferences p=Schedule.prefs(this);
        if(p.getLong(Schedule.WHEN,0L)!=expected)return;
        // Consume the one-shot schedule BEFORE clicking to prevent duplicate sends.
        String pkg=p.getString(Schedule.ARMED_PACKAGE,"");
        int count=p.getInt(Schedule.ARMED_COUNT,-1);
        p.edit().remove(Schedule.WHEN).remove(Schedule.ARMED_COUNT).remove(Schedule.ARMED_PACKAGE)
                .putString(Schedule.STATE,"發送前最後核對中").commit();
        PowerManager power=getSystemService(PowerManager.class);
        KeyguardManager lock=getSystemService(KeyguardManager.class);
        if(power==null || !power.isInteractive() || (lock!=null && lock.isDeviceLocked())){
            Schedule.mark(this,"未發送：手機已鎖定或螢幕關閉");return;
        }
        if(pkg.isEmpty()||count<=0){ Schedule.mark(this,"未發送：尚未在 LINE 畫面確認已選收件人");return; }
        Screen s=inspect();
        if(s==null || !s.validated || !pkg.equals(s.pkg) || count!=s.selected){
            Schedule.mark(this,"未發送：LINE 帳號、畫面或收件人數量與預約時不一致");return;
        }
        boolean pressed=click(s.share);
        Schedule.mark(this,pressed?"已按 LINE 右上角分享｜請到 LINE 確認是否成功送達":
                "未發送：LINE 分享按鈕點擊失敗");
    }
    @Override public void onInterrupt() { /* No blind retry. */ }
    @Override public void onDestroy() {if(current==this)current=null;super.onDestroy();}
}
