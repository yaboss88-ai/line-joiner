package tw.linescheduler.safe;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

public final class ScheduleReceiver extends BroadcastReceiver {
  static SharedPreferences prefs(Context c) { return c.getSharedPreferences("scheduled_job", Context.MODE_PRIVATE); }
  static PendingIntent alarmIntent(Context c) {
    Intent i=new Intent(c,ScheduleReceiver.class).setAction("tw.linescheduler.safe.FIRE");
    return PendingIntent.getBroadcast(c,101,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
  }
  static void schedule(Context c, Job j) throws Exception {
    AlarmManager a=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
    if(a==null)throw new Exception("無法使用排程服務");
    a.cancel(alarmIntent(c));
    prefs(c).edit().putString("job",j.toJson().toString()).putString("status","等待預約時間").apply();
    Intent show=new Intent(c,MainActivity.class);
    PendingIntent showPi=PendingIntent.getActivity(c,102,show,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    // Alarm-clock API avoids unrestricted exact-alarm privilege. Android may still restrict background UI launches.
    a.setAlarmClock(new AlarmManager.AlarmClockInfo(j.when,showPi),alarmIntent(c));
  }
  static void cancel(Context c){
    AlarmManager a=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
    if(a!=null)a.cancel(alarmIntent(c));
    prefs(c).edit().remove("job").putString("status","已取消").apply();
  }
  static void status(Context c,String s){ prefs(c).edit().putString("status",s).apply(); }
  @Override public void onReceive(Context c,Intent intent){
    try {
      String s=prefs(c).getString("job",null);
      if(s==null)return;
      Job j=Job.fromJson(s);
      if(System.currentTimeMillis()<j.when-30000){status(c,"排程過早觸發，已停止");return;}
      if(System.currentTimeMillis()>j.when+15*60000){status(c,"排程延遲過久，已停止");return;}
      // Mark before dispatch so repeat broadcasts cannot duplicate sends.
      prefs(c).edit().remove("job").putString("status","已觸發，正在確認 LINE").apply();
      LineAccessibilityService sInstance=LineAccessibilityService.instance;
      if(sInstance==null){status(c,"無障礙服務未執行，未發送");return;}
      sInstance.runTask(j);
    } catch(Exception e){status(c,"無法執行排程："+e.getClass().getSimpleName());}
  }
}
