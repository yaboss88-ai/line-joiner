package tw.linescheduler.safe;

import android.accessibilityservice.AccessibilityService;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Safety-first LINE UI automation preview.
 * Sends only when exactly one user-specified keyword matches an accessible recipient.
 * Cannot claim delivery or support "all" without a verified, complete recipient list.
 */
public final class LineAccessibilityService extends AccessibilityService {
  static volatile LineAccessibilityService instance;
  private enum Step { IDLE, WAIT_RECIPIENT, SWITCH_TAB, INPUT_SEARCH, MATCH_ONE, WAIT_SELECTED, PRESS_SHARE, DONE }
  private Step step=Step.IDLE;
  private Job job;
  private String keyword="";
  private long started, lastAction;
  private final Handler handler=new Handler(Looper.getMainLooper());
  private boolean searchSet=false;
  private boolean tabTapped=false;
  private boolean recipientClicked=false;
  private String lastCandidate="";

  @Override protected void onServiceConnected(){instance=this;}
  @Override public void onDestroy(){instance=null;job=null;super.onDestroy();}
  @Override public void onInterrupt(){fail("無障礙服務中斷，未確認發送");}
  private void status(String s){ScheduleReceiver.status(this,s);}
  private void fail(String why){
    status("已停止："+why);job=null;step=Step.IDLE;handler.removeCallbacksAndMessages(null);
  }
  public void runTask(Job scheduled){
    handler.post(()->start(scheduled));
  }
  private void start(Job j){
    if(job!=null){fail("另一筆預約仍在處理");return;}
    // Conservative boundaries: all recipients, multiple simultaneous categories and multiple keywords
    // require verified paging/batching that must not be guessed from LINE's UI.
    if(j.allGroups||j.allFriends){fail("全部收件對象尚無法驗證完整名單，未發送");return;}
    if(j.groups&&j.friends){fail("群組與個人混合發送尚未完成核驗，未發送");return;}
    if(!j.groups&&!j.friends){fail("未指定收件對象");return;}
    String raw=(j.groups?j.groupKeyword:j.friendKeyword).trim();
    if(raw.isEmpty()||raw.contains("\n")){fail("安全測試僅接受一個明確關鍵字");return;}
    this.job=j;this.keyword=raw;this.step=Step.WAIT_RECIPIENT;this.started=System.currentTimeMillis();this.lastAction=0;
    this.searchSet=false;this.tabTapped=false;this.recipientClicked=false;
    try {
      PackageManager pm=getPackageManager();
      String actual=String.valueOf(pm.getApplicationLabel(pm.getApplicationInfo(j.packageName,0)));
      if(!actual.equals(j.appLabel))throw new IllegalStateException("LINE 帳號名稱已更動");
      Intent share=new Intent(Intent.ACTION_SEND);
      if(j.imageUri.isEmpty())share.setType("text/plain");
      else {share.setType("image/*");share.putExtra(Intent.EXTRA_STREAM,Uri.parse(j.imageUri));share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);}
      if(!j.message.trim().isEmpty())share.putExtra(Intent.EXTRA_TEXT,j.message);
      share.setPackage(j.packageName);
      List<ResolveInfo> matches=pm.queryIntentActivities(share,PackageManager.MATCH_DEFAULT_ONLY);
      List<ResolveInfo> valid=new ArrayList<>();
      for(ResolveInfo r:matches){
        if(r.activityInfo==null||!r.activityInfo.exported||!j.packageName.equals(r.activityInfo.packageName))continue;
        String n=r.activityInfo.name.toLowerCase(Locale.ROOT);
        String label=String.valueOf(r.loadLabel(pm)).toLowerCase(Locale.ROOT);
        if(n.contains("keep")||n.contains("voom")||label.contains("keep")||label.contains("voom"))continue;
        valid.add(r);
      }
      if(valid.size()!=1)throw new IllegalStateException("無法唯一辨識 LINE 分享入口（找到 "+valid.size()+" 個），未發送");
      ResolveInfo only=valid.get(0);
      share.setComponent(new ComponentName(only.activityInfo.packageName,only.activityInfo.name));
      share.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
      status("已觸發，嘗試開啟 "+j.appLabel+" 收件對象頁");
      startActivity(share);
      handler.postDelayed(this::process,800);
    }catch(Exception e){fail(e.getMessage());}
  }
  @Override public void onAccessibilityEvent(AccessibilityEvent event){
    if(job==null||step==Step.IDLE||step==Step.DONE)return;
    if(event.getEventType()!=AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED&&event.getEventType()!=AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED)return;
    if(System.currentTimeMillis()-lastAction<230)return;
    handler.postDelayed(this::process,240);
  }
  private List<AccessibilityNodeInfo> nodes(AccessibilityNodeInfo n){
    List<AccessibilityNodeInfo> out=new ArrayList<>();walk(n,out,0);return out;
  }
  private void walk(AccessibilityNodeInfo n,List<AccessibilityNodeInfo> out,int depth){
    if(n==null||depth>28||out.size()>1500)return;
    out.add(n);for(int i=0;i<n.getChildCount();i++)walk(n.getChild(i),out,depth+1);
  }
  private String txt(AccessibilityNodeInfo n){
    if(n==null)return "";
    CharSequence a=n.getText(),b=n.getContentDescription();return a!=null?a.toString():b!=null?b.toString():"";
  }
  private Rect bounds(AccessibilityNodeInfo n){Rect r=new Rect();n.getBoundsInScreen(r);return r;}
  private boolean clickNode(AccessibilityNodeInfo n){
    AccessibilityNodeInfo x=n;
    for(int i=0;i<5&&x!=null;i++,x=x.getParent()){
      if(x.isClickable()&&x.performAction(AccessibilityNodeInfo.ACTION_CLICK))return true;
    }
    return false;
  }
  private AccessibilityNodeInfo textNode(List<AccessibilityNodeInfo> all,String exact){
    for(AccessibilityNodeInfo n:all)if(txt(n).trim().equals(exact))return n;return null;
  }
  private AccessibilityNodeInfo header(List<AccessibilityNodeInfo> all){
    for(AccessibilityNodeInfo n:all){
      String t=txt(n).trim();Rect r=bounds(n);
      if((t.equals("選擇傳送對象")||t.equals("选择传送对象")||t.matches("已選\\s*[（(]\\d+[）)]"))&&r.top<getResources().getDisplayMetrics().heightPixels/4)return n;
    }
    return null;
  }
  private AccessibilityNodeInfo pageTab(List<AccessibilityNodeInfo> all,String label){
    int h=getResources().getDisplayMetrics().heightPixels;
    for(AccessibilityNodeInfo n:all)if(txt(n).trim().equals(label)){
      Rect b=bounds(n);if(b.centerY()>h*.07&&b.centerY()<h*.31)return n;
    }
    return null;
  }
  private boolean selected(AccessibilityNodeInfo n){
    for(int i=0;i<3&&n!=null;i++,n=n.getParent())if(n.isSelected())return true;
    return false;
  }
  private AccessibilityNodeInfo searchField(List<AccessibilityNodeInfo> all){
    int h=getResources().getDisplayMetrics().heightPixels;
    for(AccessibilityNodeInfo n:all){
      Rect b=bounds(n);if(b.centerY()<h*.12||b.centerY()>h*.42)continue;
      String cls=n.getClassName()==null?"":n.getClassName().toString();
      if(cls.contains("EditText"))return n;
    }
    return null;
  }
  private int selectedCount(List<AccessibilityNodeInfo> all){
    for(AccessibilityNodeInfo n:all){String t=txt(n).trim();
      if(t.matches("已選\\s*[（(]\\d+[）)]")){
        String digits=t.replaceAll("[^0-9]","");try{return Integer.parseInt(digits);}catch(Exception ignored){}
      }
    }return -1;
  }
  private void process(){
    if(job==null)return;
    long now=System.currentTimeMillis();if(now-started>60000){fail("超過一分鐘未完成，停止以避免誤發");return;}
    if(now-lastAction<200)return;
    AccessibilityNodeInfo root=getRootInActiveWindow();if(root==null){return;}
    CharSequence current=root.getPackageName();
    if(current==null||!job.packageName.equals(current.toString())){
      // Do not click global chooser or another app; explicit component should avoid it.
      if(now-started>9000)fail("沒有進入指定 LINE 帳號，未發送");return;
    }
    List<AccessibilityNodeInfo> all=nodes(root);
    if(header(all)==null){if(now-started>12000)fail("未辨識 LINE 收件人畫面，未發送");return;}
    if(step==Step.WAIT_RECIPIENT)step=Step.SWITCH_TAB;
    if(step==Step.SWITCH_TAB){
      String desired=job.groups?"群組":"好友";
      AccessibilityNodeInfo tab=pageTab(all,desired);
      if(tab==null){fail("無法找到 "+desired+" 分頁");return;}
      if(!selected(tab)){
        if(tabTapped){if(now-lastAction>2500)fail("無法確認已切換 "+desired+" 分頁");return;}
        if(!clickNode(tab)){fail("無法點選 "+desired+" 分頁");return;}
        tabTapped=true;lastAction=now;return;
      }
      step=Step.INPUT_SEARCH;
    }
    if(step==Step.INPUT_SEARCH){
      AccessibilityNodeInfo field=searchField(all);
      if(field==null){fail("找不到搜尋欄位");return;}
      if(!searchSet){Bundle b=new Bundle();b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,keyword);
        if(!field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,b)){fail("LINE 不允許輸入搜尋關鍵字");return;}
        searchSet=true;step=Step.MATCH_ONE;lastAction=now;return;
      }
    }
    if(step==Step.MATCH_ONE){
      if(now-lastAction<1200)return;
      if(recipientClicked){step=Step.WAIT_SELECTED;return;}
      int screen=getResources().getDisplayMetrics().heightPixels;
      List<AccessibilityNodeInfo> matches=new ArrayList<>();
      for(AccessibilityNodeInfo n:all){
        String t=txt(n).trim();Rect b=bounds(n);
        if(b.centerY()<screen*.29||b.centerY()>screen*.88)continue;
        if(t.length()<2||t.equals(keyword)||t.equals("利用名稱搜尋"))continue;
        if(t.toLowerCase(Locale.ROOT).contains(keyword.toLowerCase(Locale.ROOT))&&n.getClassName()!=null&&n.getClassName().toString().contains("TextView"))matches.add(n);
      }
      if(matches.size()!=1){fail("關鍵字找到 "+matches.size()+" 個可辨識名稱，無法唯一確認，未發送");return;}
      lastCandidate=txt(matches.get(0));
      if(!clickNode(matches.get(0))){fail("無法勾選收件人");return;}
      recipientClicked=true;step=Step.WAIT_SELECTED;lastAction=now;return;
    }
    if(step==Step.WAIT_SELECTED){
      int count=selectedCount(all);
      if(count!=1){if(now-lastAction>5000)fail("無法確認已選 1 位收件人，未發送");return;}
      step=Step.PRESS_SHARE;
    }
    if(step==Step.PRESS_SHARE){
      AccessibilityNodeInfo share=null;int screen=getResources().getDisplayMetrics().heightPixels;
      int width=getResources().getDisplayMetrics().widthPixels;
      for(AccessibilityNodeInfo n:all){
        String t=txt(n).trim();Rect b=bounds(n);
        if(t.equals("分享")&&b.centerY()<screen*.16&&b.centerX()>width*.65){share=n;break;}
      }
      if(share==null){fail("未找到右上角分享；絕不點 LINE VOOM");return;}
      if(!clickNode(share)){fail("右上角分享無法點選");return;}
      status("已按 LINE 右上角分享，送達結果仍須在 LINE 核對："+lastCandidate);
      step=Step.DONE;job=null;
    }
  }
}
