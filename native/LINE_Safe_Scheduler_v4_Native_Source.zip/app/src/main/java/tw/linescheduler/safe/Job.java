package tw.linescheduler.safe;
import org.json.JSONObject;

public final class Job {
  public String packageName = "", appLabel = "", groupKeyword = "", friendKeyword = "", message = "", imageUri = "";
  public boolean groups, friends, allGroups, allFriends;
  public long when, nonce;
  public JSONObject toJson() throws Exception {
    JSONObject j = new JSONObject();
    j.put("packageName",packageName); j.put("appLabel",appLabel);
    j.put("groupKeyword",groupKeyword); j.put("friendKeyword",friendKeyword); j.put("message",message);
    j.put("imageUri",imageUri); j.put("groups",groups); j.put("friends",friends);
    j.put("allGroups",allGroups); j.put("allFriends",allFriends);
    j.put("when",when); j.put("nonce",nonce); return j;
  }
  public static Job fromJson(String s) throws Exception {
    JSONObject j = new JSONObject(s); Job r = new Job();
    r.packageName=j.getString("packageName");r.appLabel=j.getString("appLabel");
    r.groupKeyword=j.optString("groupKeyword");r.friendKeyword=j.optString("friendKeyword");
    r.message=j.optString("message");r.imageUri=j.optString("imageUri");
    r.groups=j.optBoolean("groups");r.friends=j.optBoolean("friends");
    r.allGroups=j.optBoolean("allGroups");r.allFriends=j.optBoolean("allFriends");
    r.when=j.getLong("when");r.nonce=j.getLong("nonce");return r;
  }
}
