package tw.linescheduler.safe;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.Manifest;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Locale;
import java.util.List;
import java.util.Set;

public final class MainActivity extends Activity {
  private static final int PICK_IMAGE=101;
  private final List<Account> accounts=new ArrayList<>();
  private Spinner accountSelect;
  private EditText groupWords, friendWords, message;
  private CheckBox groupEnabled,friendEnabled,consent;
  private RadioButton groupAll,groupSearch,friendAll,friendSearch;
  private TextView accountHint,imageHint,timeHint,statusHint,countdown;
  private String imageUri="";
  private long plannedTime=0;
  private final Handler handler=new Handler(Looper.getMainLooper());
  private final Runnable refresh=new Runnable(){@Override public void run(){updateStatus();handler.postDelayed(this,1000);}};
  private static final int BLUE=Color.rgb(31,104,151);
  private static class Account {
    final String pkg,label;
    Account(String p,String l){pkg=p;label=l;}
    @Override public String toString(){return label+"（"+pkg+"）";}
  }
  @Override public void onCreate(Bundle b){super.onCreate(b);buildUi();scanAccounts();}
  @Override protected void onResume(){super.onResume();handler.removeCallbacks(refresh);handler.post(refresh);}
  @Override protected void onPause(){handler.removeCallbacks(refresh);super.onPause();}
  private int px(float dp){return Math.round(dp*getResources().getDisplayMetrics().density);}
  private LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
  private void pad(View v){v.setPadding(px(16),px(10),px(16),px(10));}
  private TextView title(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextColor(BLUE);t.setTextSize(size); t.setPadding(0,px(9),0,px(9));return t;}
  private Button button(String s,Runnable r){Button b=new Button(this);b.setText(s);b.setOnClickListener(v->r.run());return b;}
  private EditText input(String hint){EditText i=new EditText(this);i.setHint(hint);i.setTextSize(16);return i;}
  private LinearLayout section(LinearLayout parent,String heading){LinearLayout l=vertical();pad(l);l.setBackgroundColor(Color.WHITE);
    LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(px(8),px(7),px(8),px(7));parent.addView(l,p);
    l.addView(title(heading,19));return l;}
  private void buildUi(){
    ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(Color.rgb(242,247,251));
    LinearLayout root=vertical();scroll.addView(root);setContentView(scroll);
    TextView header=title("LINE 智慧定時發訊 v4.0｜原生安全測試版",21);pad(header);header.setTextColor(Color.WHITE);header.setBackgroundColor(Color.rgb(91,155,221));root.addView(header);
    LinearLayout a=section(root,"① 選擇 LINE 帳號");
    a.addView(button("更新 LINE 帳號",this::scanAccounts));
    accountSelect=new Spinner(this);a.addView(accountSelect,new LinearLayout.LayoutParams(-1,px(58)));
    accountHint=new TextView(this);a.addView(accountHint);
    LinearLayout r=section(root,"② 選擇收件對象");
    groupEnabled=new CheckBox(this);groupEnabled.setText("LINE 一般群組");groupEnabled.setChecked(true);r.addView(groupEnabled);
    RadioGroup gm=new RadioGroup(this);groupAll=new RadioButton(this);groupAll.setText("全部一般群組");groupSearch=new RadioButton(this);groupSearch.setText("關鍵字搜尋指定群組");gm.addView(groupAll);gm.addView(groupSearch);r.addView(gm);groupSearch.setChecked(true);
    groupWords=input("群組關鍵字（建議唯一識別名稱）");r.addView(groupWords);
    friendEnabled=new CheckBox(this);friendEnabled.setText("LINE 個人好友");r.addView(friendEnabled);
    RadioGroup fm=new RadioGroup(this);friendAll=new RadioButton(this);friendAll.setText("全部好友");friendSearch=new RadioButton(this);friendSearch.setText("關鍵字搜尋指定好友");fm.addView(friendAll);fm.addView(friendSearch);r.addView(fm);friendSearch.setChecked(true);
    friendWords=input("好友名稱或編號，例如 F1102");r.addView(friendWords);
    groupEnabled.setOnCheckedChangeListener((b,on)->updateRecipientVisibility());friendEnabled.setOnCheckedChangeListener((b,on)->updateRecipientVisibility());
    gm.setOnCheckedChangeListener((b,id)->updateRecipientVisibility());fm.setOnCheckedChangeListener((b,id)->updateRecipientVisibility());updateRecipientVisibility();
    TextView caution=new TextView(this);caution.setText("安全測試：無法唯一確認收件人、無法讀取群組清單時，不執行發送。LINE 社群不支援。");r.addView(caution);
    LinearLayout m=section(root,"③ 發送內容");message=input("預約發送的文字（可以只選圖片）");message.setMinLines(3);m.addView(message);
    m.addView(button("選擇圖片（相簿／檔案）",this::pickImage));imageHint=new TextView(this);imageHint.setText("尚未選擇圖片");m.addView(imageHint);
    m.addView(button("清除圖片",()->{imageUri="";imageHint.setText("尚未選擇圖片");}));
    LinearLayout t=section(root,"④ 預約日期與時間");
    timeHint=title("請先選擇預約時間",18);t.addView(timeHint);
    t.addView(button("選日期及時間",this::pickTime));
    consent=new CheckBox(this);consent.setText("我已核對帳號、對象、時間，且對方同意接收訊息");t.addView(consent);
    t.addView(button("確認預約發送",this::schedule));
    countdown=title("尚未建立預約",21);countdown.setGravity(Gravity.CENTER);t.addView(countdown);
    t.addView(button("取消這筆預約",()->{ScheduleReceiver.cancel(this);updateStatus();}));
    statusHint=new TextView(this);t.addView(statusHint);
    LinearLayout advanced=section(root,"權限與安全狀態");
    advanced.addView(button("開啟無障礙設定",()->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));
    TextView permission=new TextView(this);permission.setText("使用無障礙服務可能讀取螢幕內容；請只在信任此程式後開啟。若手機鎖定、權限失效或 LINE 介面不符，排程會停止。");advanced.addView(permission);
    if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},1);}
  }
  private void updateRecipientVisibility(){
    if(groupWords==null||friendWords==null)return;
    groupWords.setVisibility(groupEnabled.isChecked()&&groupSearch.isChecked()?View.VISIBLE:View.GONE);
    friendWords.setVisibility(friendEnabled.isChecked()&&friendSearch.isChecked()?View.VISIBLE:View.GONE);
    groupAll.setVisibility(groupEnabled.isChecked()?View.VISIBLE:View.GONE);
    groupSearch.setVisibility(groupEnabled.isChecked()?View.VISIBLE:View.GONE);
    friendAll.setVisibility(friendEnabled.isChecked()?View.VISIBLE:View.GONE);
    friendSearch.setVisibility(friendEnabled.isChecked()?View.VISIBLE:View.GONE);
  }
  private void scanAccounts(){
    if(accountSelect==null)return;
    accounts.clear();Set<String> seen=new HashSet<>();
    PackageManager pm=getPackageManager();Intent i=new Intent(Intent.ACTION_MAIN);i.addCategory(Intent.CATEGORY_LAUNCHER);
    for(ResolveInfo info:pm.queryIntentActivities(i,0)){
      if(info.activityInfo==null)continue;
      String pkg=info.activityInfo.packageName;
      try {
        ApplicationInfo app=pm.getApplicationInfo(pkg,0);
        String label=String.valueOf(pm.getApplicationLabel(app)).trim();
        // Do not confuse tools named LINE or LINE Bank with a LINE messaging account.
        if(pkg.startsWith("jp.naver.line.and")&&label.matches("(?i)^LINE(?:[0-9]{1,2})?$ ".trim())&&seen.add(pkg)) accounts.add(new Account(pkg,label));
      }catch(Exception ignored){}
    }
    accounts.sort((x,y)->x.label.compareToIgnoreCase(y.label));
    ArrayAdapter<Account> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,accounts);adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);accountSelect.setAdapter(adapter);
    accountHint.setText("已找到 "+accounts.size()+" 個 LINE；安全資料夾裡的帳號可能無法取得。");
  }
  private void pickImage(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);startActivityForResult(i,PICK_IMAGE);}
  @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);
    if(request==PICK_IMAGE&&result==RESULT_OK&&data!=null&&data.getData()!=null){
      Uri u=data.getData();try{getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}
      imageUri=u.toString();imageHint.setText("已選擇圖片");
    }
  }
  private void pickTime(){Calendar c=Calendar.getInstance();c.add(Calendar.MINUTE,5);
    new DatePickerDialog(this,(d,y,mo,day)->{new TimePickerDialog(this,(td,h,min)->{
      Calendar p=Calendar.getInstance();p.set(y,mo,day,h,min,0);p.set(Calendar.MILLISECOND,0);
      plannedTime=p.getTimeInMillis();timeHint.setText(new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.TAIWAN).format(p.getTime()));
    },c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE),true).show();},c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show();
  }
  private void schedule(){
    try {
      if(accounts.isEmpty()||accountSelect.getSelectedItemPosition()<0)throw new Exception("請先更新並選擇 LINE 帳號");
      if(!consent.isChecked())throw new Exception("請先核對收件對象並勾選同意");
      if(!groupEnabled.isChecked()&&!friendEnabled.isChecked())throw new Exception("請選擇群組或好友");
      if(groupEnabled.isChecked()&&groupSearch.isChecked()&&groupWords.getText().toString().trim().isEmpty())throw new Exception("請輸入群組關鍵字");
      if(friendEnabled.isChecked()&&friendSearch.isChecked()&&friendWords.getText().toString().trim().isEmpty())throw new Exception("請輸入好友關鍵字");
      if(message.getText().toString().trim().isEmpty()&&imageUri.isEmpty())throw new Exception("請輸入文字或選擇圖片");
      if(plannedTime<System.currentTimeMillis()+60000)throw new Exception("預約時間須至少在一分鐘之後");
      Account a=(Account)accountSelect.getSelectedItem();Job j=new Job();
      j.packageName=a.pkg;j.appLabel=a.label;j.groups=groupEnabled.isChecked();j.friends=friendEnabled.isChecked();j.allGroups=groupAll.isChecked();j.allFriends=friendAll.isChecked();
      j.groupKeyword=groupWords.getText().toString().trim();j.friendKeyword=friendWords.getText().toString().trim();
      j.message=message.getText().toString();j.imageUri=imageUri;j.when=plannedTime;j.nonce=System.currentTimeMillis();
      ScheduleReceiver.schedule(this,j);Toast.makeText(this,"已建立預約（發送須再經安全核對）",Toast.LENGTH_LONG).show();updateStatus();
    }catch(Exception e){Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();}
  }
  private void updateStatus(){
    String s=ScheduleReceiver.prefs(this).getString("status","沒有預約");
    if(statusHint!=null)statusHint.setText("狀態："+s);
    String data=ScheduleReceiver.prefs(this).getString("job",null);
    if(countdown==null)return;
    if(data==null){countdown.setText("沒有等待中的預約");return;}
    try{
      long n=Math.max(0,Job.fromJson(data).when-System.currentTimeMillis());
      long d=n/86400000,h=n/3600000%24,m=n/60000%60,sec=n/1000%60;
      countdown.setText(String.format(Locale.TAIWAN,"距離發送：%d天 %02d:%02d:%02d",d,h,m,sec));
    }catch(Exception e){countdown.setText("預約資訊無法讀取");}
  }
}
