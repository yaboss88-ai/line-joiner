LINE 智慧定時發訊 v4.0 原生 Android 原始碼（安全重建測試專案）

重要：這不是已可安裝的 APK。Google 已拒絕舊 Auto.js APK 下載，不能把同一框架換名再發布。
本專案不含舊 Auto.js APK 的二進位檔，也不需要麥克風、定位、裝卸 APP 權限。

功能與狀態：
- 原生 Android Java 使用者介面：LINE 帳號下拉選擇、群組/好友模式、關鍵字、文字/圖片選擇、預約時間、倒數、取消預約。
- Android AlarmManager.setAlarmClock：一次性預約，避免要求額外的精確鬧鐘權限。
- 選定 LINE 帳號的 Android 分享入口（若無法唯一辨識即停止）。
- 無障礙服務僅試行「單一關鍵字、唯一收件人、右上角分享」安全測試。
- 群組全選、好友全選、群組與好友同時發送、多人關鍵字命中尚未實作；這些模式會安全停止，不會誤發。
- LINE UI 可能因版本、分身、手機安全設定改變而無法完成自動操作。
- Android 15 背景活動啟動、鎖定畫面會阻止全自動操作；尚未通過三星實機測試。

編譯：用 Android Studio（含 Android SDK 35、AGP 8.6.1）打開此資料夾，Sync Project、Build APK(s)。
目前執行環境沒有 Android SDK，無法驗證編譯或產出簽章 APK。

權限：只宣告 POST_NOTIFICATIONS；無障礙服務須使用者在設定中明確授權。
安全限制：沒有精確確認帳號/收件人時停止；不觸碰 LINE VOOM；不存收件人名單；沒有自動重試。
